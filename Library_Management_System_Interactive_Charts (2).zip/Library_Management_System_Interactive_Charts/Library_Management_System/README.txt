LIBRARY MANAGEMENT SYSTEM
=========================

This is a beginner-friendly Python project.

Technologies:
- Python
- Flask
- HTML
- CSS
- CSV files
- Classes
- Functions
- Lists
- Dictionaries
- Exception handling

IMPORTANT:
This project does NOT use JSON.
This project does NOT use a database.

PROJECT STRUCTURE
-----------------

Library_Management_System/
|
|-- app.py
|-- library.py
|-- requirements.txt
|-- README.txt
|
|-- data/
|   |-- books.csv
|   |-- students.csv
|   |-- transactions.csv
|
|-- templates/
|   |-- base.html
|   |-- index.html
|   |-- books.html
|   |-- add_book.html
|   |-- students.html
|   |-- add_student.html
|   |-- search.html
|   |-- issue_book.html
|   |-- return_book.html
|   |-- transactions.html
|
|-- static/
    |-- style.css


HOW TO RUN
----------

1. Open this project folder in VS Code.

2. Open Terminal.

3. Install Flask:

   pip install flask

   OR:

   pip install -r requirements.txt

4. Run the project:

   python app.py

5. Open the browser:

   http://127.0.0.1:5000


HOW TO USE
----------

STEP 1:
Go to "Books" and add some books.

Example:
Book ID: B001
Title: Python Basics
Author: John Smith
Year: 2025

STEP 2:
Go to "Students" and add a student.

Example:
Student ID: S001
Name: Rahul Das
Email: rahul@example.com
Phone: 9876543210

STEP 3:
Go to "Issue Book".

Enter:
Book ID: B001
Student ID: S001

The book will become "Issued".

STEP 4:
Go to "Return Book".

Enter:
Book ID: B001

The book will become "Available" again.

OVERDUE CHARGE
--------------

The loan period is 14 days.

If a book is returned late:

Charge = Number of late days × ₹5

Example:
3 late days × ₹5 = ₹15


IMPORTANT PYTHON TOPICS USED
----------------------------

1. Classes
   - Book
   - Student
   - Library

2. Objects
   - Each Book and Student is an object.

3. Lists
   - self.books
   - self.students
   - self.transactions

4. Dictionaries
   - Transaction records use dictionaries.

5. Functions
   - add_book()
   - add_student()
   - search_books()
   - issue_book()
   - return_book()
   - save_books()
   - load_data()

6. File Handling
   - CSV files are used to save records.

7. Exception Handling
   - try
   - except
   - ValueError
   - FileNotFoundError

8. Conditions
   - if
   - else

9. Loops
   - for loops

10. Simple Statistics
   - Total books
   - Available books
   - Issued books
   - Most issued book


NO JSON
-------

This project intentionally does not use JSON.

Data is stored in:
- books.csv
- students.csv
- transactions.csv


NOTE
----

The CSV files are automatically updated when you add books,
students, issue books or return books.
