from pathlib import Path
from collections import Counter
from datetime import datetime
import os

from flask import Flask, render_template, request, redirect, url_for, flash
from library import Library

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =====================================
# APPLICATION SETUP
# =====================================

BASE_DIR = Path(__file__).resolve().parent
os.chdir(BASE_DIR)  # library.py uses relative paths such as data/books.csv

app = Flask(__name__)
app.secret_key = "library-secret-key"

library = Library()
library.load_data()

STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(exist_ok=True)


# =====================================
# CHART 1: BAR CHART
# =====================================

def create_bar_chart():
    categories = ["Books", "Students", "Transactions"]
    values = [
        len(library.books),
        len(library.students),
        len(library.transactions)
    ]

    fig, ax = plt.subplots(figsize=(8, 4.8))
    bars = ax.bar(
        categories,
        values,
        color=["#3498db", "#2ecc71", "#f39c12"],
        width=0.55
    )

    ax.set_title("Library Management Statistics", fontsize=15, pad=15)
    ax.set_xlabel("Categories")
    ax.set_ylabel("Total Count")
    ax.set_ylim(0, max(values + [1]) * 1.18)
    ax.grid(axis="y", alpha=0.25)

    for bar in bars:
        height = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            height,
            str(int(height)),
            ha="center",
            va="bottom"
        )

    fig.tight_layout()
    fig.savefig(STATIC_DIR / "bar_chart.png", dpi=120)
    plt.close(fig)


# =====================================
# CHART 2: LINE GRAPH
# Monthly book issue trend
# =====================================

def create_line_graph():
    monthly_issues = Counter()

    for transaction in library.transactions:
        try:
            issue_date = datetime.strptime(
                transaction.get("issue_date", "").strip(),
                "%Y-%m-%d"
            )
            month_key = issue_date.strftime("%Y-%m")
            monthly_issues[month_key] += 1
        except (ValueError, TypeError, AttributeError):
            continue

    months = sorted(monthly_issues)
    counts = [monthly_issues[month] for month in months]

    fig, ax = plt.subplots(figsize=(8, 4.8))

    if months:
        ax.plot(
            months,
            counts,
            marker="o",
            linewidth=2.5,
            markersize=7,
            color="#3498db"
        )
        ax.set_xticks(range(len(months)))
        ax.set_xticklabels(months, rotation=35, ha="right")

        for index, count in enumerate(counts):
            ax.annotate(
                str(count),
                (index, count),
                textcoords="offset points",
                xytext=(0, 8),
                ha="center"
            )
    else:
        ax.text(
            0.5, 0.5,
            "No issue records available",
            ha="center",
            va="center",
            transform=ax.transAxes
        )

    ax.set_title("Monthly Book Issue Trend", fontsize=15, pad=15)
    ax.set_xlabel("Month")
    ax.set_ylabel("Number of Issues")
    ax.grid(alpha=0.25)

    fig.tight_layout()
    fig.savefig(STATIC_DIR / "line_graph.png", dpi=120)
    plt.close(fig)


# =====================================
# CHART 3: HISTOGRAM
# Book publication year distribution
# =====================================

def create_histogram():
    publication_years = []

    for book in library.books:
        try:
            year = int(str(book.year).strip())
            if 0 < year <= datetime.now().year:
                publication_years.append(year)
        except (ValueError, TypeError):
            continue

    fig, ax = plt.subplots(figsize=(8, 4.8))

    if publication_years:
        number_of_bins = min(10, max(1, len(set(publication_years))))
        ax.hist(
            publication_years,
            bins=number_of_bins,
            color="#9b59b6",
            edgecolor="white",
            linewidth=1.2
        )
    else:
        ax.text(
            0.5, 0.5,
            "No valid publication year data",
            ha="center",
            va="center",
            transform=ax.transAxes
        )

    ax.set_title("Book Publication Year Distribution", fontsize=15, pad=15)
    ax.set_xlabel("Publication Year")
    ax.set_ylabel("Number of Books")
    ax.grid(axis="y", alpha=0.25)

    fig.tight_layout()
    fig.savefig(STATIC_DIR / "histogram.png", dpi=120)
    plt.close(fig)


# =====================================
# CREATE ALL CHARTS
# =====================================

def create_charts():
    create_bar_chart()
    create_line_graph()
    create_histogram()


# =====================================
# HOME / DASHBOARD
# =====================================

@app.route("/")
def home():
    create_charts()
    return render_template("index.html", library=library)


# =====================================
# BOOKS WITH AUTHOR FILTER
# =====================================

@app.route("/books")
def books():
    all_books = library.books
    author = request.args.get("author", "").strip()

    if author:
        all_books = [
            book for book in all_books
            if author.lower() in book.author.lower()
        ]

    return render_template(
        "books.html",
        library=library,
        books=all_books,
        selected_author=author
    )


# =====================================
# STUDENTS
# =====================================

@app.route("/students")
def students():
    return render_template(
        "students.html",
        library=library,
        students=library.students
    )


# =====================================
# TRANSACTIONS
# =====================================

@app.route("/transactions")
def transactions():
    return render_template(
        "transactions.html",
        library=library,
        transactions=library.transactions
    )


# =====================================
# ADD BOOK
# =====================================

@app.route("/add-book", methods=["GET", "POST"])
def add_book():
    if request.method == "POST":
        try:
            book_id = request.form["book_id"].strip()
            title = request.form["title"].strip()
            author = request.form["author"].strip()
            year = request.form["year"].strip()

            library.add_book(book_id, title, author, year)
            flash("Book added successfully!", "success")
            return redirect(url_for("books"))

        except ValueError as error:
            flash(str(error), "error")

    return render_template("add_book.html", library=library)


# =====================================
# ADD STUDENT
# =====================================

@app.route("/add-student", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        try:
            student_id = request.form["student_id"].strip()
            name = request.form["name"].strip()
            email = request.form["email"].strip()
            phone = request.form["phone"].strip()

            library.add_student(student_id, name, email, phone)
            flash("Student added successfully!", "success")
            return redirect(url_for("students"))

        except ValueError as error:
            flash(str(error), "error")

    return render_template("add_student.html", library=library)


# =====================================
# SEARCH BOOKS
# =====================================

@app.route("/search", methods=["GET", "POST"])
def search():
    results = []

    if request.method == "POST":
        keyword = request.form["keyword"].strip()

        if keyword:
            results = library.search_books(keyword)
        else:
            flash("Please enter a title or author.", "error")

    return render_template(
        "search.html",
        library=library,
        results=results
    )


# =====================================
# ISSUE BOOK
# =====================================

@app.route("/issue", methods=["GET", "POST"])
def issue_book():
    if request.method == "POST":
        try:
            book_id = request.form["book_id"].strip()
            student_id = request.form["student_id"].strip()

            library.issue_book(book_id, student_id)
            flash("Book issued successfully!", "success")
            return redirect(url_for("transactions"))

        except ValueError as error:
            flash(str(error), "error")

    return render_template("issue_book.html", library=library)


# =====================================
# RETURN BOOK
# =====================================

@app.route("/return", methods=["GET", "POST"])
def return_book():
    if request.method == "POST":
        try:
            book_id = request.form["book_id"].strip()
            charge = library.return_book(book_id)

            if charge > 0:
                flash(
                    f"Book returned. Overdue charge: ₹{charge}",
                    "success"
                )
            else:
                flash(
                    "Book returned successfully. No overdue charge.",
                    "success"
                )

            return redirect(url_for("transactions"))

        except ValueError as error:
            flash(str(error), "error")

    return render_template("return_book.html", library=library)


# =====================================
# RUN FLASK APPLICATION
# =====================================

if __name__ == "__main__":
    app.run(debug=True)
