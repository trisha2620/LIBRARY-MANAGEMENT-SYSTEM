import csv
from datetime import date, datetime, timedelta


class Book:
    def __init__(self, book_id, title, author, year, status="Available"):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.year = year
        self.status = status


class Student:
    def __init__(self, student_id, name, email, phone):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.phone = phone


class Library:
    def __init__(self):
        # Lists store books, students and transactions
        self.books = []
        self.students = []
        self.transactions = []

    # ---------------- BOOK FUNCTIONS ----------------

    def add_book(self, book_id, title, author, year):
        if not book_id or not title or not author or not year:
            raise ValueError("Please fill all book fields.")

        for book in self.books:
            if book.book_id == book_id:
                raise ValueError("This Book ID already exists.")

        new_book = Book(book_id, title, author, year)
        self.books.append(new_book)
        self.save_books()

    def search_books(self, keyword):
        results = []
        keyword = keyword.lower()

        for book in self.books:
            if keyword in book.title.lower() or keyword in book.author.lower():
                results.append(book)

        return results

    # ---------------- STUDENT FUNCTIONS ----------------

    def add_student(self, student_id, name, email, phone):
        if not student_id or not name or not email or not phone:
            raise ValueError("Please fill all student fields.")

        for student in self.students:
            if student.student_id == student_id:
                raise ValueError("This Student ID already exists.")

        new_student = Student(student_id, name, email, phone)
        self.students.append(new_student)
        self.save_students()

    # ---------------- ISSUE FUNCTION ----------------

    def issue_book(self, book_id, student_id):
        book = self.find_book(book_id)
        student = self.find_student(student_id)

        if book is None:
            raise ValueError("Book ID not found.")

        if student is None:
            raise ValueError("Student ID not found.")

        if book.status == "Issued":
            raise ValueError("This book is already issued.")

        issue_date = date.today()
        due_date = issue_date + timedelta(days=14)

        book.status = "Issued"

        transaction = {
            "book_id": book.book_id,
            "book_title": book.title,
            "student_id": student.student_id,
            "student_name": student.name,
            "issue_date": issue_date.strftime("%Y-%m-%d"),
            "due_date": due_date.strftime("%Y-%m-%d"),
            "return_date": "",
            "charge": "0",
            "status": "Issued"
        }

        self.transactions.append(transaction)
        self.save_books()
        self.save_transactions()

    # ---------------- RETURN FUNCTION ----------------

    def return_book(self, book_id):
        book = self.find_book(book_id)

        if book is None:
            raise ValueError("Book ID not found.")

        if book.status == "Available":
            raise ValueError("This book is already available.")

        for transaction in reversed(self.transactions):
            if transaction["book_id"] == book_id and transaction["status"] == "Issued":

                return_date = date.today()
                due_date = datetime.strptime(
                    transaction["due_date"], "%Y-%m-%d"
                ).date()

                late_days = (return_date - due_date).days

                # Simple overdue charge:
                # ₹5 for each late day
                if late_days > 0:
                    charge = late_days * 5
                else:
                    charge = 0

                transaction["return_date"] = return_date.strftime("%Y-%m-%d")
                transaction["charge"] = str(charge)
                transaction["status"] = "Returned"

                book.status = "Available"

                self.save_books()
                self.save_transactions()

                return charge

        raise ValueError("No active issue record found for this book.")

    # ---------------- FIND FUNCTIONS ----------------

    def find_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id:
                return book
        return None

    def find_student(self, student_id):
        for student in self.students:
            if student.student_id == student_id:
                return student
        return None

    # ---------------- STATISTICS ----------------

    def available_count(self):
        count = 0

        for book in self.books:
            if book.status == "Available":
                count += 1

        return count

    def issued_count(self):
        count = 0

        for book in self.books:
            if book.status == "Issued":
                count += 1

        return count

    def most_issued_book(self):
        if len(self.transactions) == 0:
            return "No data yet"

        counts = {}

        for transaction in self.transactions:
            title = transaction["book_title"]

            if title not in counts:
                counts[title] = 0

            counts[title] += 1

        most_book = max(counts, key=counts.get)
        return most_book

    # ---------------- FILE FUNCTIONS ----------------

    def save_books(self):
        with open("data/books.csv", "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)

            writer.writerow(["book_id", "title", "author", "year", "status"])

            for book in self.books:
                writer.writerow([
                    book.book_id,
                    book.title,
                    book.author,
                    book.year,
                    book.status
                ])

    def save_students(self):
        with open("data/students.csv", "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)

            writer.writerow(["student_id", "name", "email", "phone"])

            for student in self.students:
                writer.writerow([
                    student.student_id,
                    student.name,
                    student.email,
                    student.phone
                ])

    def save_transactions(self):
        with open("data/transactions.csv", "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)

            writer.writerow([
                "book_id",
                "book_title",
                "student_id",
                "student_name",
                "issue_date",
                "due_date",
                "return_date",
                "charge",
                "status"
            ])

            for transaction in self.transactions:
                writer.writerow([
                    transaction["book_id"],
                    transaction["book_title"],
                    transaction["student_id"],
                    transaction["student_name"],
                    transaction["issue_date"],
                    transaction["due_date"],
                    transaction["return_date"],
                    transaction["charge"],
                    transaction["status"]
                ])

    def load_data(self):
        # Load books
        try:
            with open("data/books.csv", "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    book = Book(
                        row["book_id"],
                        row["title"],
                        row["author"],
                        row["year"],
                        row["status"]
                    )
                    self.books.append(book)
        except FileNotFoundError:
            pass

        # Load students
        try:
            with open("data/students.csv", "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    student = Student(
                        row["student_id"],
                        row["name"],
                        row["email"],
                        row["phone"]
                    )
                    self.students.append(student)
        except FileNotFoundError:
            pass

        # Load transactions
        try:
            with open("data/transactions.csv", "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    self.transactions.append(row)
        except FileNotFoundError:
            pass
